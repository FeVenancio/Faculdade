public class Node {
    String vagao;
    Node proximo;

    public Node(String vagao) {
        this.vagao = vagao;
        this.proximo = null;
    }
} 
