public class Node {
    char data;
    Node next;

    public Node(char data) {
        this.data = data;
    }

    public Node() {

    }
}
