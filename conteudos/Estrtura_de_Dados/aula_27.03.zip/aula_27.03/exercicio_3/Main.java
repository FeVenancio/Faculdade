public class Main {
    public static void main(String[] args) {

        Lista l = new Lista();

        l.add(1);
        l.add(2);
        l.add(3);
        l.add(4);
        l.add(5);
        l.add(6);

        Lista p = l.pares();

        System.out.print("pares: ");
        p.print();
    }
}
