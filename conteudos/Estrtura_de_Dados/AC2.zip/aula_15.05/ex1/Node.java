package ex1;
public class Node {
    
    public String data;
    public Node next;

    public Node(String data) {
        this.data = data;
    }

    public Node() {
    }
}
